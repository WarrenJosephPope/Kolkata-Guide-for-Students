function college(){
	document.getElementById("college_list").style.display="block";
}

function close_college_list(){
	document.getElementById("college_list").style.display="none";
}