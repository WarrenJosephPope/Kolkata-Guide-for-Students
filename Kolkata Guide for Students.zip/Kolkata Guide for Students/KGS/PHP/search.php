<script src="/KGS/Scripts/search.js"></script>
<div id="search_bar">
    <img style="cursor:pointer;" onclick="close_search()" src="/KGS/Pictures/back.png"></img>
	<input style="margin:0" id="search_text" type="text" autocomplete="off" name="search_text" placeholder="Search"/>
    <div id="result">
        
    </div>
</div>