<div id="header">
	<a id="logo" style="display:inline-block;font-style:italic;text-decoration:none;" href="/KGS/">Kolkata Students' Guide</a>
	<span id="search"><img style="cursor:pointer" onclick="open_search()" src="/KGS/Pictures/search.png"></img><span>
</div>